﻿namespace ETickets.Infrastructure.Data.Enums
{
    public enum MovieCategory
    {
        Action = 1,
        Comedy,
        Drama,
        Thriller,
        Documentary,
        Horror,
        Cartoon
    }
}
