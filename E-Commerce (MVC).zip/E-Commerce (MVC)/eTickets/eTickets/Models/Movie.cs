﻿using ETickets.Infrastructure.Data.Base;
using ETickets.Infrastructure.Data.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ETickets.Core.Models
{
    public class Movie : IEntityBase
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Movie Title")]
        public string Name { get; set; }
        [Display(Name = "Movie Preview")]
        public string Description { get; set; }
        [Display(Name = "Movie Price")]
        public double Price { get; set; }
        [Display(Name = "Movie Picture")]
        public string Image { get; set; }
        [Display(Name = "Movie release date")]
        public DateTime StartDate { get; set; }
        [Display(Name = "Movie expiry date")]
        public DateTime EndDate { get; set; }
        [Display(Name = "Category")]
        public MovieCategory MovieCategory { get; set; }

        //Relationships
        public List<Actor_Movie> Actors_Movies { get; set; }

        //Cinema
        public Cinema Cinema { get; set; }
        [ForeignKey("CinemaId")]
        public int CinemaId { get; set; }

        //Producer
        public Producer Producer { get; set; }
        [ForeignKey("ProducerId")]
        public int ProducerId { get; set; }

    }
}
