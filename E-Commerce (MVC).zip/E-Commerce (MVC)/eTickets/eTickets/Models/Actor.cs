﻿using ETickets.Infrastructure.Data.Base;
using System.ComponentModel.DataAnnotations;

namespace ETickets.Core.Models
{
    public class Actor : IEntityBase
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name = "Profile Picture")]
        public string ProfilePictureUrl { get; set; }
        [Required]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }
        [Required]
        [Display(Name = "Biography")]
        public string Bio { get; set; }

        //Relationships
        public List<Actor_Movie>? Actors_Movies { get; set; }

    }
}
