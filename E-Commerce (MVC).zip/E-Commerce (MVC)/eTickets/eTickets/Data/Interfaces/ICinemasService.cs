﻿using ETickets.Core.Models;
using ETickets.Infrastructure.Data.Base;

namespace eTickets.Data.Interfaces
{
    public interface ICinemasService : IEntityBaseRepository<Cinema>
    {
    }
}
