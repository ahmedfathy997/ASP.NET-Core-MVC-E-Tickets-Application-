﻿using eTickets.Data.Interfaces;
using ETickets.Core.Models;
using ETickets.Infrastructure.Data;
using ETickets.Infrastructure.Data.Base;

namespace eTickets.Data.Services
{
    public class CinemasService : EntityBaseRepository<Cinema>, ICinemasService
    {
        public CinemasService(AppDbContext context) : base(context) { }
    }
}